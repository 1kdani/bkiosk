"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useState, useRef, useEffect } from "react";
import { Map as MapIcon, ZoomIn, ZoomOut, Maximize, Loader2 } from "lucide-react";
import { db } from "@/lib/firebase";
import { doc, onSnapshot } from "firebase/firestore";

interface FloorMap {
  id: string;
  name: string;
  imageUrl: string;
}

export default function MapPanel() {
  const [floors, setFloors] = useState<FloorMap[]>([]);
  const [activeFloorId, setActiveFloorId] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [scale, setScale] = useState(1);
  
  const constraintsRef = useRef<HTMLDivElement>(null);

  // Adatok lekérése a Firestore-ból
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, "settings", "maps"), (docSnap) => {
      if (docSnap.exists() && docSnap.data().floors) {
        const floorData = docSnap.data().floors as FloorMap[];
        setFloors(floorData);
        if (floorData.length > 0 && !activeFloorId) {
          setActiveFloorId(floorData[0].id);
        }
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [activeFloorId]);

  const handleZoomIn = () => setScale((prev) => Math.min(prev + 0.5, 3));
  const handleZoomOut = () => setScale((prev) => Math.max(prev - 0.5, 1));
  const handleResetZoom = () => setScale(1);

  if (loading) {
    return <div className="h-full flex items-center justify-center"><Loader2 className="w-12 h-12 animate-spin text-orange-500" /></div>;
  }

  const activeFloor = floors.find((f) => f.id === activeFloorId);

  return (
    <div className="w-full h-full flex flex-col relative pb-6 font-sans">
      
      {/* Fejléc és Szintválasztó */}
      <div className="flex justify-between items-center bg-orange-50 p-6 rounded-3xl mb-8 border border-orange-100 shrink-0 z-10">
        <div className="flex items-center gap-4">
          <MapIcon className="w-10 h-10 text-orange-600" />
          <div>
            <h4 className="text-2xl font-bold text-orange-900">Iskola Térkép</h4>
            <p className="text-orange-700">Terembeosztás és tájékozódás</p>
          </div>
        </div>
        
        <div className="flex gap-2 bg-white p-2 rounded-2xl shadow-sm overflow-x-auto max-w-xl custom-scrollbar touch-pan-x">
          {floors.map((floor) => (
            <button
              key={floor.id}
              onClick={() => {
                setActiveFloorId(floor.id);
                setScale(1); // Szintváltáskor visszaállítjuk a zoomot
              }}
              className={`px-6 py-3 rounded-xl font-bold text-lg transition-all whitespace-nowrap ${
                activeFloorId === floor.id 
                  ? "bg-orange-500 text-white shadow-md" 
                  : "bg-orange-50 text-orange-700 hover:bg-orange-100"
              }`}
            >
              {floor.name}
            </button>
          ))}
          {floors.length === 0 && <span className="p-3 text-orange-500 font-bold">Nincsenek feltöltött térképek.</span>}
        </div>
      </div>

      {/* Interaktív Térkép Terület */}
      <div className="flex-1 relative bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-inner flex items-center justify-center">
        
        {/* Irányító gombok (Zoom) */}
        <div className="absolute right-6 bottom-6 flex flex-col gap-3 z-20">
          <button onClick={handleZoomIn} className="bg-white p-4 rounded-2xl shadow-lg border border-slate-200 text-slate-700 hover:text-orange-600 hover:border-orange-200 transition-colors">
            <ZoomIn className="w-8 h-8" />
          </button>
          <button onClick={handleResetZoom} className="bg-white p-4 rounded-2xl shadow-lg border border-slate-200 text-slate-700 hover:text-orange-600 hover:border-orange-200 transition-colors">
            <Maximize className="w-8 h-8" />
          </button>
          <button onClick={handleZoomOut} className="bg-white p-4 rounded-2xl shadow-lg border border-slate-200 text-slate-700 hover:text-orange-600 hover:border-orange-200 transition-colors">
            <ZoomOut className="w-8 h-8" />
          </button>
        </div>

        {activeFloor && activeFloor.imageUrl ? (
          <div ref={constraintsRef} className="w-full h-full relative flex items-center justify-center">
            <motion.div
              drag
              dragConstraints={constraintsRef}
              dragElastic={0.1}
              animate={{ scale }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="cursor-grab active:cursor-grabbing w-full h-full flex items-center justify-center"
            >
              <img 
                src={activeFloor.imageUrl} 
                alt={activeFloor.name} 
                className="max-w-none max-h-none object-contain pointer-events-none drop-shadow-xl"
                style={{ width: "90%", height: "90%" }} 
              />
            </motion.div>
          </div>
        ) : (
          <div className="text-center text-slate-400 p-12">
            <MapIcon className="w-24 h-24 mx-auto mb-6 opacity-20" />
            <h3 className="text-3xl font-bold text-slate-500 mb-2">A térkép hamarosan elérhető</h3>
            <p className="text-xl">Az adminisztrátorok hamarosan feltöltik az alaprajzokat.</p>
          </div>
        )}
      </div>
    </div>
  );
}