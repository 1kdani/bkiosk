"use client";

import { motion } from "framer-motion";
import { Bell, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { doc, onSnapshot } from "firebase/firestore";

interface BellClass {
  id: string;
  period: string;
  time: string;
  breakText: string;
}

export default function BellsPanel() {
  const [bellSchedule, setBellSchedule] = useState<BellClass[]>([]);
  const [loading, setLoading] = useState(true);

  // Valós idejű szinkronizáció az admin panellel
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, "settings", "bells"), (doc) => {
      if (doc.exists() && doc.data().schedule) {
        setBellSchedule(doc.data().schedule);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  if (loading) {
    return <div className="h-full flex items-center justify-center"><Loader2 className="w-12 h-12 animate-spin text-purple-500" /></div>;
  }

  return (
    <div className="w-full max-w-4xl mx-auto h-full flex flex-col pb-6">
      <div className="bg-purple-50 p-6 rounded-3xl mb-8 border border-purple-100 flex items-center gap-4 shrink-0">
        <Bell className="w-10 h-10 text-purple-600" />
        <div>
          <h4 className="text-2xl font-bold text-purple-900">Normál csengetési rend</h4>
          <p className="text-purple-700">SZTE Báthory István Gyakorló</p>
        </div>
      </div>

      {/* A titok: touch-pan-y az érintős görgetéshez, pb-32 az alsó helyért */}
      <div className="flex-1 overflow-y-auto touch-pan-y pr-4 pb-32 space-y-4 snap-y custom-scrollbar">
        {bellSchedule.map((schedule, index) => {
          let isNow = false;
          try {
            const timeParts = schedule.time.split("-").map(t => t.trim());
            if (timeParts.length === 2) {
              const [startHour, startMin] = timeParts[0].split(":");
              const [endHour, endMin] = timeParts[1].split(":");
              const startTotal = parseInt(startHour) * 60 + parseInt(startMin);
              const endTotal = parseInt(endHour) * 60 + parseInt(endMin);
              isNow = currentMinutes >= startTotal && currentMinutes <= endTotal;
            }
          } catch (e) {} // Hibakezelés ha rossz formátumban írják be

          return (
            <motion.div 
              key={schedule.id || index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`flex items-center justify-between p-6 rounded-2xl border snap-start ${
                isNow 
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-200 border-purple-600 scale-[1.02] transform transition-transform" 
                  : "bg-white text-slate-700 border-slate-100 hover:border-purple-200"
              }`}
            >
              <div className="flex items-center gap-8">
                <div className={`text-3xl font-black ${isNow ? "text-purple-200" : "text-slate-300"}`}>
                  {index + 1}
                </div>
                <div>
                  <h5 className={`text-xl font-bold ${isNow ? "text-white" : "text-slate-800"}`}>
                    {schedule.period}
                  </h5>
                  <p className={`text-3xl font-light tracking-tight mt-1 ${isNow ? "text-white" : "text-slate-500"}`}>
                    {schedule.time}
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className={`px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider ${
                  isNow ? "bg-purple-500/50 text-white" : "bg-slate-100 text-slate-500"
                }`}>
                  {schedule.breakText}
                </span>
                {isNow && (
                  <span className="animate-pulse flex items-center gap-2 text-purple-200 font-medium">
                    <span className="w-2 h-2 rounded-full bg-green-400" /> Éppen tart
                  </span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}