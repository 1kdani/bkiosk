"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { Newspaper, CalendarDays, Map, BellRing, X, ChevronRight } from "lucide-react";
import BellsPanel from "./BellsPanel";
import NewsPanel from "./NewsPanel";
import TimetablePanel from "./TimetablePanel";
import MapPanel from "./MapPanel";

const menuItems = [
  { id: "news", title: "Aktuális Hírek", desc: "Iskolai események és felhívások", icon: Newspaper, color: "text-blue-500", bgColor: "bg-blue-50" },
  { id: "timetable", title: "Órarendek", desc: "Tanári és osztály órarendek", icon: CalendarDays, color: "text-emerald-500", bgColor: "bg-emerald-50" },
  { id: "map", title: "Iskola Térkép", desc: "Terembeosztás és 3D térkép", icon: Map, color: "text-orange-500", bgColor: "bg-orange-50" },
  { id: "bells", title: "Csengetési Rend", desc: "Tanórák és szünetek ideje", icon: BellRing, color: "text-purple-500", bgColor: "bg-purple-50" },
];

export default function InteractiveDashboard() {
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full h-full bg-[#f8fafc] flex flex-col relative overflow-hidden font-sans">
      
      {/* Ugyanaz a háttér stílus */}
      <div className="absolute inset-0 bg-white/30 backdrop-blur-3xl z-0" />

      {/* --- KÖZÖS FEJLÉC (Megegyezik az IdleScreen-nel) --- */}
      <div className="absolute top-10 left-12 right-12 flex justify-between items-start z-20">
        <div>
          <h2 className="text-xl font-bold tracking-widest uppercase text-slate-400">
            SZTE Báthory István
          </h2>
          <div className="w-12 h-1 bg-blue-500 mt-2 rounded-full" />
        </div>
        <div className="text-right">
          <h1 className="text-6xl font-light text-slate-800 tracking-tighter">
            {time.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}
          </h1>
          <p className="text-xl text-slate-500 font-medium mt-1 uppercase tracking-wider">
            {time.toLocaleDateString('hu-HU', { month: 'long', day: 'numeric', weekday: 'long' })}
          </p>
        </div>
      </div>

      {/* --- FŐ TARTALOM --- */}
      <div className="flex-1 relative z-10 pt-44 px-12 pb-12">
        <AnimatePresence mode="wait">
          {!activeTab ? (
            <motion.div
              key="grid"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20, scale: 0.98 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-2 gap-10 h-full max-w-6xl mx-auto"
            >
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <motion.button
                    key={item.id}
                    whileHover={{ y: -8 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setActiveTab(item.id)}
                    className="bg-white rounded-[2.5rem] p-10 flex flex-col justify-between text-left shadow-sm border border-slate-200 group transition-all hover:shadow-[0_20px_50px_rgb(0,0,0,0.06)]"
                  >
                    <div className={`${item.bgColor} w-20 h-20 rounded-2xl flex items-center justify-center mb-6`}>
                      <Icon className={`w-10 h-10 ${item.color}`} />
                    </div>
                    <div>
                      <h3 className="text-4xl font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-xl text-slate-500">{item.desc}</p>
                    </div>
                  </motion.button>
                );
              })}
            </motion.div>
          ) : (
            <motion.div
              key="panel"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full h-full bg-white rounded-[3rem] p-10 shadow-xl border border-slate-200 flex flex-col"
            >
              <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-6">
                <h3 className="text-4xl font-bold text-slate-800">
                  {menuItems.find((m) => m.id === activeTab)?.title}
                </h3>
                <button
                  onClick={() => setActiveTab(null)}
                  className="px-6 py-4 bg-slate-100 text-slate-700 font-bold rounded-full hover:bg-slate-200 transition-colors flex items-center gap-2"
                >
                  <X className="w-6 h-6" /> Vissza a menübe
                </button>
              </div>
              <div className="flex-1 overflow-y-auto mt-8">
                {activeTab === "bells" && <BellsPanel />}
                {activeTab === "news" && <NewsPanel />}
                {activeTab === "timetable" && <TimetablePanel />}
                {activeTab === "map" && <MapPanel />}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}