"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { Loader2, X, Image as ImageIcon } from "lucide-react";

interface NewsItem {
  id: string;
  title: string;
  content: string;
  tag: string;
  imageUrl?: string;
}

export default function NewsPanel() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);

  useEffect(() => {
    const q = query(collection(db, "news"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as NewsItem[];
      setNews(newsData);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="w-12 h-12 animate-spin text-blue-500" /></div>;

  return (
    <div className="w-full h-full relative flex flex-col">
      {/* Görgethető hír rács */}
      <div className="flex-1 overflow-y-auto touch-pan-y pr-4 pb-32 w-full grid grid-cols-2 gap-8 custom-scrollbar">
        {news.map((item, index) => (
          <motion.button
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => setSelectedNews(item)}
            className="bg-slate-50 rounded-[2rem] p-8 text-left border border-slate-100 hover:shadow-lg transition-all flex flex-col h-80 group overflow-hidden relative"
          >
            {item.imageUrl && (
              <div className="absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity z-0">
                <img src={item.imageUrl} alt="" className="w-full h-full object-cover" />
              </div>
            )}
            <div className="relative z-10 flex flex-col h-full">
              <span className="inline-block px-4 py-1.5 rounded-full bg-blue-100 text-blue-700 font-bold uppercase text-xs w-max mb-4">
                {item.tag}
              </span>
              <h3 className="text-3xl font-bold text-slate-800 mb-3 line-clamp-2 leading-tight">
                {item.title}
              </h3>
              <p className="text-lg text-slate-500 line-clamp-3">
                {item.content}
              </p>
              <div className="mt-auto pt-4 text-blue-600 font-bold text-lg">
                Elolvasom →
              </div>
            </div>
          </motion.button>
        ))}
      </div>

      {/* Felugró Részletes Hír Modal */}
      <AnimatePresence>
        {selectedNews && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-white/60 backdrop-blur-md flex items-center justify-center p-12"
          >
            <motion.div
              initial={{ scale: 0.9, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 50 }}
              className="bg-white w-full max-w-5xl rounded-[3rem] shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-full"
            >
              {selectedNews.imageUrl && (
                <div className="w-full h-64 relative shrink-0">
                  <img src={selectedNews.imageUrl} alt="" className="w-full h-full object-cover" />
                  <button 
                    onClick={() => setSelectedNews(null)}
                    className="absolute top-6 right-6 bg-black/50 backdrop-blur-md text-white p-3 rounded-full"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              )}
              
              <div className="p-12 overflow-y-auto touch-pan-y relative flex-1">
                {!selectedNews.imageUrl && (
                  <button 
                    onClick={() => setSelectedNews(null)}
                    className="absolute top-8 right-8 bg-slate-100 text-slate-600 p-3 rounded-full"
                  >
                    <X className="w-6 h-6" />
                  </button>
                )}
                
                <span className="inline-block px-4 py-1.5 rounded-full bg-blue-100 text-blue-700 font-bold uppercase text-sm mb-6">
                  {selectedNews.tag}
                </span>
                <h2 className="text-5xl font-black text-slate-900 mb-8 leading-tight">
                  {selectedNews.title}
                </h2>
                <div className="text-2xl text-slate-600 leading-relaxed whitespace-pre-wrap">
                  {selectedNews.content}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}