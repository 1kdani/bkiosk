"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";

interface NewsItem {
  id: string;
  title: string;
  content: string;
  tag: string;
  color: string;
  template: "default" | "image-left" | "image-top";
  imageUrl?: string;
}

const dummyNews: NewsItem[] = [
  { 
    id: "d1", 
    tag: "Rendszer", 
    title: "Üdvözlünk az új TV Panelben", 
    content: "<p>Ez egy példa hír. Amint feltöltesz egy valós hírt az adminisztrációs felületről, ezek a példák automatikusan eltűnnek.</p>", 
    color: "#3b82f6",
    template: "default"
  }
];

export default function IdleScreen() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [time, setTime] = useState<Date | null>(null);

  useEffect(() => {
    setTime(new Date()); // Kliens oldalon azonnal beállítjuk
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const q = query(collection(db, "news"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as NewsItem[];
      setNews(newsData);
    });
    return () => unsubscribe();
  }, []);

  const displayNews = news.length > 0 ? news : dummyNews;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % displayNews.length);
    }, 12000);
    return () => clearInterval(timer);
  }, [displayNews.length]);

  const currentNews = displayNews[currentIndex];
  const activeColor = currentNews?.color || "#3b82f6";

  return (
    <div className="w-full h-full bg-[#f8fafc] text-slate-800 flex flex-col relative overflow-hidden font-sans">
      
      <style dangerouslySetInnerHTML={{ __html: `
        .noise-bg {
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.04'/%3E%3C/svg%3E");
        }
        /* JAVÍTVA: Kisebb sorközök és margók a Quill szövegszerkesztő kimenetén */
        .quill-content p { margin-bottom: 0.3rem; line-height: 1.4; }
        .quill-content strong { font-weight: 800; color: #0f172a; }
        .quill-content em { font-style: italic; }
        .quill-content ul { list-style-type: disc; padding-left: 2rem; margin-bottom: 0.3rem; }
        .quill-content ol { list-style-type: decimal; padding-left: 2rem; margin-bottom: 0.3rem; }
        
        /* JAVÍTVA: Ha a tartalom túl hosszú, max 8 sor után "..."-al levágja */
        .line-clamp-8 {
          display: -webkit-box;
          -webkit-line-clamp: 8;
          -webkit-box-orient: vertical;
          overflow: hidden;
          word-break: break-word; /* Szavak eltörése ha túl hosszúak */
        }
      `}} />

      <div className="absolute inset-0 noise-bg pointer-events-none opacity-50 z-0" />
      
      <motion.div animate={{ backgroundColor: activeColor }} transition={{ duration: 1.5 }} className="absolute -top-40 -left-40 w-96 h-96 rounded-full blur-[120px] z-0 opacity-30" />
      <motion.div animate={{ backgroundColor: activeColor }} transition={{ duration: 1.5 }} className="absolute bottom-10 -right-20 w-[40rem] h-[40rem] rounded-full blur-[150px] z-0 opacity-20" />

      <div className="absolute top-10 left-12 right-12 flex justify-between items-start z-20">
        <div>
          <h2 className="text-xl font-bold tracking-widest uppercase text-slate-400">SZTE Báthory István</h2>
          <motion.div animate={{ backgroundColor: activeColor }} className="w-12 h-1 mt-2 rounded-full" />
        </div>
        <div className="text-right bg-white/50 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/50 shadow-sm">
          <h1 className="text-5xl font-bold text-slate-800 tracking-tighter">
            {time ? time.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }) : "--:--"}
          </h1>
          <p className="text-lg text-slate-500 font-bold mt-1 uppercase tracking-wider">
            {time ? time.toLocaleDateString('hu-HU', { month: 'long', day: 'numeric', weekday: 'long' }) : "Betöltés..."}
          </p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-12 z-10 w-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentNews.id}
            initial={{ opacity: 0, filter: "blur(10px)", y: 20 }}
            animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
            exit={{ opacity: 0, filter: "blur(10px)", y: -20 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className={`w-full max-w-6xl bg-white/70 backdrop-blur-2xl rounded-[3rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border border-white/60 overflow-hidden flex ${currentNews.template === 'image-left' ? 'flex-row' : 'flex-col'}`}
          >
            {currentNews.imageUrl && currentNews.template === 'image-top' && (
              <div className="w-full h-[22rem] relative shrink-0">
                <img src={currentNews.imageUrl} alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-white/70 to-transparent" />
              </div>
            )}
            
            {currentNews.imageUrl && currentNews.template === 'image-left' && (
              <div className="w-1/2 relative shrink-0">
                <img src={currentNews.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-white/70" />
              </div>
            )}

            <div className={`p-16 flex-1 flex flex-col justify-center ${currentNews.template === 'default' || !currentNews.imageUrl ? 'items-center text-center' : ''}`}>
              <span className="inline-block px-5 py-2 text-sm font-black uppercase tracking-widest rounded-full mb-6 shadow-sm" style={{ backgroundColor: `${activeColor}20`, color: activeColor }}>
                {currentNews.tag}
              </span>
              
              {/* JAVÍTVA: A cím max 3 sor lehet, utána pont-pont-pont */}
              <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-6 leading-[1.1] tracking-tight line-clamp-3 break-words">
                {currentNews.title}
              </h2>
              
              {/* JAVÍTVA: Hozzáadtuk a line-clamp-8 osztályt */}
              <div 
                className="quill-content text-2xl text-slate-500 font-light max-w-4xl line-clamp-8"
                dangerouslySetInnerHTML={{ __html: currentNews.content }} 
              />
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 z-20">
        <motion.div animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0.8, 0.3] }} transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: activeColor }} />
        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-slate-400">Érintse meg a képernyőt</span>
      </div>
    </div>
  );
}