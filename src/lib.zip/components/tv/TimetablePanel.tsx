"use client";

import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { CalendarDays, Loader2, Users, GraduationCap, Clock } from "lucide-react";
import { db } from "@/lib/firebase";
import { collection, onSnapshot, query, doc, getDoc } from "firebase/firestore";

const days = ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek"];
const periods = ["1.", "2.", "3.", "4.", "5.", "6.", "7.", "8."];

const periodTimes: Record<string, string> = {
  "1.": "07:25 - 08:10",
  "2.": "08:20 - 09:05",
  "3.": "09:20 - 10:05",
  "4.": "10:20 - 11:05",
  "5.": "11:15 - 12:00",
  "6.": "12:20 - 13:05",
  "7.": "13:15 - 14:00",
  "8.": "14:10 - 14:55",
};

type ScheduleData = Record<string, Record<string, { subject: string; room: string; teacher: string }>>;
type ClassDoc = { id: string; schedule: ScheduleData };

const getSubjectColor = (subject: string) => {
  const s = subject.toLowerCase();
  if (s.includes("mate") || s.includes("analízis")) return "bg-blue-100 text-blue-800 border-blue-200";
  if (s.includes("magyar") || s.includes("irodalom") || s.includes("nyelvtan")) return "bg-rose-100 text-rose-800 border-rose-200";
  if (s.includes("töri") || s.includes("történelem")) return "bg-amber-100 text-amber-800 border-amber-200";
  if (s.includes("angol") || s.includes("német") || s.includes("francia")) return "bg-emerald-100 text-emerald-800 border-emerald-200";
  if (s.includes("tesi") || s.includes("testnevelés")) return "bg-orange-100 text-orange-800 border-orange-200";
  if (s.includes("info") || s.includes("dig")) return "bg-indigo-100 text-indigo-800 border-indigo-200";
  if (s.includes("fizika") || s.includes("kémia") || s.includes("bio") || s.includes("természet")) return "bg-teal-100 text-teal-800 border-teal-200";
  return "bg-slate-100 text-slate-800 border-slate-200";
};

export default function TimetablePanel() {
  const [classesData, setClassesData] = useState<ClassDoc[]>([]);
  const [teachers, setTeachers] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"class" | "teacher">("class");
  const [selectedTarget, setSelectedTarget] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const metaDoc = await getDoc(doc(db, "settings", "timetable_meta"));
      if (metaDoc.exists() && metaDoc.data().teachers) {
        setTeachers(metaDoc.data().teachers.sort());
      }
      
      const q = query(collection(db, "timetables"));
      onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, schedule: doc.data().schedule || {} }));
        data.sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
        setClassesData(data);
        if (data.length > 0 && !selectedTarget && viewMode === "class") setSelectedTarget(data[0].id);
        setLoading(false);
      });
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (viewMode === "class" && classesData.length > 0) setSelectedTarget(classesData[0].id);
    if (viewMode === "teacher" && teachers.length > 0) setSelectedTarget(teachers[0]);
  }, [viewMode, classesData, teachers]);

  const getTeacherSchedule = (teacherName: string): ScheduleData => {
    const tSchedule: ScheduleData = {};
    days.forEach(day => {
      tSchedule[day] = {};
      periods.forEach(period => {
        classesData.forEach(cls => {
          const lesson = cls.schedule[day]?.[period];
          if (lesson && lesson.teacher === teacherName) {
            tSchedule[day][period] = { subject: lesson.subject, room: lesson.room, teacher: cls.id }; 
          }
        });
      });
    });
    return tSchedule;
  };

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="w-12 h-12 animate-spin text-blue-500" /></div>;

  const currentSchedule = viewMode === "class" 
    ? classesData.find(c => c.id === selectedTarget)?.schedule || {} 
    : getTeacherSchedule(selectedTarget);
  
  const optionsList = viewMode === "class" ? classesData.map(c => c.id) : teachers;

  return (
    <div className="w-full h-full flex flex-col relative pb-6 bg-[#f8fafc] font-sans">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-white p-6 rounded-3xl mb-6 shadow-sm border border-slate-200 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center">
            <CalendarDays className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h4 className="text-2xl font-black text-slate-800 tracking-tight">Órarendek</h4>
            <p className="text-slate-500 font-medium">{viewMode === 'class' ? 'Osztályok' : 'Tanárok'} heti beosztása</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
          <div className="relative w-full sm:w-64">
            <select 
              value={selectedTarget} 
              onChange={(e) => setSelectedTarget(e.target.value)}
              className="w-full appearance-none bg-slate-50 border border-slate-200 text-slate-800 font-bold text-lg px-6 py-3 rounded-2xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all cursor-pointer"
            >
              {optionsList.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
            <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
              <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </div>
          </div>

          <div className="flex bg-slate-100 p-1.5 rounded-2xl">
            <button onClick={() => setViewMode("class")} className={`flex-1 px-4 py-2 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${viewMode === "class" ? "bg-white text-blue-600 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
              <GraduationCap className="w-5 h-5"/> Osztály
            </button>
            <button onClick={() => setViewMode("teacher")} className={`flex-1 px-4 py-2 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${viewMode === "teacher" ? "bg-white text-blue-600 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
              <Users className="w-5 h-5"/> Tanár
            </button>
          </div>
        </div>
      </div>

      {/* 
        A TITOK ITT VAN: min-h-0 ! 
        Ettől a konténer nem nyúlik ki a képernyőből, hanem aktiválja a belső görgetést.
      */}
      <div className="flex-1 bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col relative min-h-0">
        
        {/* Görgethető tároló */}
        <div className="flex-1 overflow-auto touch-pan-x touch-pan-y custom-scrollbar w-full relative">
          
          <div className="min-w-[1000px] w-full flex flex-col">
            {/* Fejléc Sor (Napok) - z-40 hogy felül maradjon görgetéskor */}
            <div className="grid grid-cols-[100px_repeat(5,1fr)] bg-slate-50 sticky top-0 z-40 border-b border-slate-200 shadow-sm">
              <div className="p-4 flex items-center justify-center border-r border-slate-200 sticky left-0 z-50 bg-slate-50">
                <Clock className="w-6 h-6 text-slate-400" />
              </div>
              {days.map(day => (
                <div key={day} className="p-4 text-center font-black text-slate-800 text-lg uppercase tracking-wider border-r border-slate-100 last:border-r-0">
                  {day}
                </div>
              ))}
            </div>

            {/* Órák Sorai */}
            {periods.map((period) => (
              <div key={period} className="grid grid-cols-[100px_repeat(5,1fr)] border-b border-slate-100 last:border-b-0 hover:bg-slate-50/30 transition-colors group">
                
                {/* Időpont oszlop - z-30 hogy bal oldalt ragadjon meg */}
                <div className="p-4 border-r border-slate-200 flex flex-col items-center justify-center sticky left-0 z-30 bg-white group-hover:bg-slate-50/90 transition-colors">
                  <span className="text-2xl font-black text-slate-800">{period.replace('.', '')}</span>
                  <span className="text-xs font-bold text-slate-400 mt-1 whitespace-nowrap">{periodTimes[period]}</span>
                </div>

                {/* Tantárgy Cellák (Hétfő-Péntek) */}
                {days.map((day, i) => {
                  const lesson = currentSchedule[day]?.[period];
                  
                  return (
                    <div key={`${day}-${period}`} className="p-3 border-r border-slate-100 last:border-r-0 relative min-h-[110px]">
                      {lesson?.subject ? (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: i * 0.03 }}
                          className={`w-full h-full p-3 rounded-xl border flex flex-col justify-between ${getSubjectColor(lesson.subject)} shadow-sm`}
                        >
                          <div className="font-bold text-base leading-tight truncate" title={lesson.subject}>
                            {lesson.subject}
                          </div>
                          
                          <div className="mt-2 flex flex-col gap-0.5">
                            {lesson.room && (
                              <div className="text-xs font-bold opacity-75 truncate flex items-center gap-1">
                                🏠 {lesson.room}
                              </div>
                            )}
                            {lesson.teacher && (
                              <div className="text-[11px] font-bold opacity-80 truncate uppercase tracking-wider mt-1">
                                {viewMode === 'class' ? lesson.teacher : `Osztály: ${lesson.teacher}`}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      ) : (
                        <div className="w-full h-full border-2 border-dashed border-slate-100 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-slate-200 font-bold text-sm">-</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

        </div>
      </div>
      
    </div>
  );
}