"use client";

import { useStore } from "@/store/useStore";
import { auth } from "@/lib/firebase";
import { signOut } from "firebase/auth";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Newspaper, Users, Settings, LogOut, LayoutDashboard, CalendarDays, UserCircle } from "lucide-react";

export default function Sidebar() {
  const { user, userName, permissions } = useStore();
  const pathname = usePathname();

  const handleLogout = async () => await signOut(auth);

  // A menüpontok most már az új, specifikus jogosultságokat nézik
  const navItems = [
    { name: "Vezérlőpult", href: "/admin", icon: LayoutDashboard, show: true },
    { name: "Hírek kezelése", href: "/admin/news", icon: Newspaper, show: permissions?.manageNews || false },
    { name: "Órarendek", href: "/admin/timetable", icon: CalendarDays, show: permissions?.manageTimetable || false },
    { name: "Felhasználók", href: "/admin/users", icon: Users, show: permissions?.manageUsers || false },
    { name: "Rendszer", href: "/admin/settings", icon: Settings, show: permissions?.manageSettings || false },
  ];

  return (
    <div className="w-72 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 shadow-sm z-20 relative">
      <div>
        <div className="h-20 flex items-center px-8 border-b border-slate-100">
          <div className="w-3 h-8 bg-blue-600 rounded-full mr-3"></div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">Báthory Kiosk</h2>
        </div>
        <nav className="p-6 space-y-2">
          {navItems.filter(item => item.show).map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link key={item.name} href={item.href} className={`flex items-center gap-4 px-4 py-3.5 rounded-xl text-[15px] font-bold transition-all ${isActive ? "bg-blue-600 text-white shadow-md shadow-blue-200" : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"}`}>
                <Icon className={`w-5 h-5 ${isActive ? "text-white" : "text-slate-400"}`} />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-6 border-t border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-4 mb-6 bg-white p-3 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center shrink-0">
            <UserCircle className="w-6 h-6 text-blue-600" />
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-bold text-slate-800 truncate">{userName || "Felhasználó"}</p>
            <p className="text-xs font-medium text-slate-400 truncate">{user?.email}</p>
          </div>
        </div>
        <button onClick={handleLogout} className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-sm font-bold text-red-600 bg-red-50 hover:bg-red-100 transition-colors">
          <LogOut className="w-5 h-5" /> Kijelentkezés
        </button>
      </div>
    </div>
  );
}