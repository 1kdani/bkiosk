import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Báthory Kiosk",
};

export default function TvLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="w-screen h-screen overflow-hidden bg-zinc-950 text-white select-none overscroll-none touch-manipulation">
      <style dangerouslySetInnerHTML={{ __html: `
        img {
          -webkit-user-drag: none;
          -khtml-user-drag: none;
          -moz-user-drag: none;
          -o-user-drag: none;
          user-drag: none;
        }
      `}} />
      {children}
    </div>
  );
}