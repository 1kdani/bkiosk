"use client";

import { useStore } from "@/store/useStore";
import { Newspaper, MonitorPlay, Users, HelpCircle } from "lucide-react";

export default function AdminPage() {
  const { userName } = useStore();

  return (
    <div className="max-w-6xl mx-auto space-y-10">
      <div>
        <h1 className="text-4xl font-black text-slate-900 tracking-tight">Üdvözlünk, {userName || "Kolléga"}! 👋</h1>
        <p className="text-lg text-slate-500 mt-2 font-medium">Itt kezelheted a portán lévő TV összes tartalmát.</p>
      </div>

      {/* Statisztikák */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
          <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center"><Newspaper className="w-8 h-8 text-blue-600"/></div>
          <div><p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Aktív Hírek</p><p className="text-3xl font-black text-slate-800">5</p></div>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center"><MonitorPlay className="w-8 h-8 text-emerald-600"/></div>
          <div><p className="text-sm font-bold text-slate-400 uppercase tracking-wider">TV Kijelzők</p><p className="text-3xl font-black text-slate-800">1</p></div>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
          <div className="w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center"><Users className="w-8 h-8 text-purple-600"/></div>
          <div><p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Rendszergazdák</p><p className="text-3xl font-black text-slate-800">3</p></div>
        </div>
      </div>

      {/* Tutorial / Gyorstalpaló */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-10 text-white shadow-xl relative overflow-hidden">
        <HelpCircle className="absolute -right-10 -bottom-10 w-64 h-64 text-white/5 rotate-12" />
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
          <span className="bg-white/20 p-2 rounded-lg">🚀</span> Gyorstalpaló a rendszerhez
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
          <div>
            <h3 className="font-bold text-blue-300 text-lg mb-2">Hírek közzététele</h3>
            <p className="text-slate-300 leading-relaxed">A Hírek menüpontban Word-szerűen formázhatod a szövegeket. Kérlek figyelj arra, hogy a TV-n a nagyon hosszú szövegek nehezen olvashatók, próbálj lényegretörő lenni!</p>
          </div>
          <div>
            <h3 className="font-bold text-emerald-300 text-lg mb-2">Színek és Sablonok</h3>
            <p className="text-slate-300 leading-relaxed">Minden hírhez egyedi háttérszínt és elrendezési sablont adhatsz meg. A TV kijelzője intelligensen felveszi a hírhez beállított színt.</p>
          </div>
        </div>
      </div>
    </div>
  );
}