"use client";

import { useState, useEffect } from "react";
import { db, firebaseConfig } from "@/lib/firebase";
import { collection, getDocs, doc, setDoc, deleteDoc, updateDoc } from "firebase/firestore";
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signOut, sendPasswordResetEmail } from "firebase/auth";
import { UserPlus, Shield, Loader2, Trash2, Edit2, X, CheckSquare, Square, Mail } from "lucide-react";
import { useStore, UserPermissions } from "@/store/useStore";

interface UserData {
  id: string;
  email: string;
  name: string;
  permissions: UserPermissions;
  createdAt: string;
}

export default function UsersAdminPage() {
  const { permissions: currentUserPerms } = useStore();
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const defaultPerms: UserPermissions = { manageNews: false, manageTimetable: false, manageSettings: false, manageUsers: false };
  const [formData, setFormData] = useState({ name: "", email: "", permissions: defaultPerms });

  const fetchUsers = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "users"));
      setUsers(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as UserData[]);
    } catch (error) { console.error(error); } 
    finally { setLoading(false); }
  };

  useEffect(() => {
    if (currentUserPerms?.manageUsers) fetchUsers();
  }, [currentUserPerms]);

  const togglePermission = (key: keyof UserPermissions) => {
    setFormData(prev => ({ ...prev, permissions: { ...prev.permissions, [key]: !prev.permissions[key] } }));
  };

  const handleEdit = (u: UserData) => {
    setFormData({ name: u.name || "", email: u.email, permissions: u.permissions || defaultPerms });
    setEditingId(u.id);
    setShowForm(true);
  };

  const handleCancel = () => {
    setFormData({ name: "", email: "", permissions: defaultPerms });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (editingId) {
        // Meglévő módosítása
        await updateDoc(doc(db, "users", editingId), { name: formData.name, permissions: formData.permissions });
        alert("Felhasználó adatai frissítve!");
      } else {
        // Új fiók létrehozása generált jelszóval
        const secondaryApp = initializeApp(firebaseConfig, "SecondaryApp");
        const secondaryAuth = getAuth(secondaryApp);
        
        const randomPassword = Math.random().toString(36).slice(-10) + "A1!"; 
        const userCredential = await createUserWithEmailAndPassword(secondaryAuth, formData.email, randomPassword);
        
        await setDoc(doc(db, "users", userCredential.user.uid), {
          email: formData.email,
          name: formData.name,
          permissions: formData.permissions,
          createdAt: new Date().toISOString(),
        });

        // Küldünk egy jelszó beállító emailt!
        await sendPasswordResetEmail(secondaryAuth, formData.email);
        await signOut(secondaryAuth);
        
        alert("Fiók létrehozva! A rendszer elküldte a beállító emailt a felhasználónak.");
      }
      handleCancel();
      fetchUsers();
    } catch (error: any) { alert("Hiba: " + error.message); } 
    finally { setIsSubmitting(false); }
  };

  const handleDeleteUser = async (userId: string) => {
    if (confirm("Biztosan törölni akarod ennek a felhasználónak a hozzáférését?")) {
      await deleteDoc(doc(db, "users", userId));
      fetchUsers();
    }
  };

  if (!currentUserPerms?.manageUsers) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-500">
        <Shield className="w-16 h-16 mb-4 text-gray-300" />
        <h2 className="text-2xl font-bold">Nincs jogosultságod</h2>
        <p>Ezt az oldalt csak a rendszergazdák láthatják.</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Felhasználók kezelése</h1>
          <p className="text-slate-500 mt-1 font-medium">Fiókok létrehozása és részletes jogosultságok kezelése.</p>
        </div>
        {!showForm && (
          <button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-md shadow-blue-200">
            <UserPlus className="w-5 h-5" /> Új munkatárs hozzáadása
          </button>
        )}
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-lg border border-slate-200">
          <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-4">
            <h2 className="text-2xl font-bold text-slate-800">{editingId ? "Felhasználó módosítása" : "Új fiók generálása"}</h2>
            {!editingId && <span className="bg-amber-50 text-amber-600 font-bold px-4 py-2 rounded-xl text-sm flex items-center gap-2"><Mail className="w-4 h-4"/> Jelszó beállító emailt fog kapni</span>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Teljes Név</label>
                <input required type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full px-5 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 font-bold" placeholder="pl. Kiss János" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Email cím (Bejelentkezéshez)</label>
                <input required disabled={!!editingId} type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full px-5 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 font-bold disabled:bg-slate-100 disabled:text-slate-400" placeholder="tanar@bathory.hu" />
                {editingId && <p className="text-xs text-slate-400 mt-1">Az email cím utólag nem módosítható.</p>}
              </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
              <label className="block text-sm font-black text-slate-800 mb-4 uppercase tracking-wider">Részletes Jogosultságok</label>
              <div className="space-y-4">
                <button type="button" onClick={() => togglePermission("manageNews")} className="flex items-center gap-3 w-full text-left group">
                  {formData.permissions.manageNews ? <CheckSquare className="w-6 h-6 text-blue-600" /> : <Square className="w-6 h-6 text-slate-400 group-hover:text-blue-400" />}
                  <span className="font-bold text-slate-700">Hírek kezelése (Létrehozás, szerkesztés, törlés)</span>
                </button>
                <button type="button" onClick={() => togglePermission("manageTimetable")} className="flex items-center gap-3 w-full text-left group">
                  {formData.permissions.manageTimetable ? <CheckSquare className="w-6 h-6 text-emerald-600" /> : <Square className="w-6 h-6 text-slate-400 group-hover:text-emerald-400" />}
                  <span className="font-bold text-slate-700">Órarendek kezelése (Tanárok, osztályok)</span>
                </button>
                <button type="button" onClick={() => togglePermission("manageSettings")} className="flex items-center gap-3 w-full text-left group">
                  {formData.permissions.manageSettings ? <CheckSquare className="w-6 h-6 text-orange-600" /> : <Square className="w-6 h-6 text-slate-400 group-hover:text-orange-400" />}
                  <span className="font-bold text-slate-700">Rendszer beállítások (Csengetés, Térkép)</span>
                </button>
                <button type="button" onClick={() => togglePermission("manageUsers")} className="flex items-center gap-3 w-full text-left group">
                  {formData.permissions.manageUsers ? <CheckSquare className="w-6 h-6 text-red-600" /> : <Square className="w-6 h-6 text-slate-400 group-hover:text-red-400" />}
                  <span className="font-bold text-slate-700">Felhasználók és Adminok kezelése</span>
                </button>
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-4">
            <button type="button" onClick={handleCancel} className="bg-red-50 hover:bg-red-100 text-red-600 px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all">
              <X className="w-5 h-5" /> Mégse
            </button>
            <button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-md shadow-blue-200 disabled:opacity-50">
              {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Shield className="w-5 h-5" />}
              {editingId ? "Jogosultságok Frissítése" : "Fiók Létrehozása"}
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-sm">
                <th className="px-6 py-5 font-bold uppercase tracking-wider">Név / Email</th>
                <th className="px-6 py-5 font-bold uppercase tracking-wider">Aktív Jogosultságok</th>
                <th className="px-6 py-5 font-bold uppercase tracking-wider text-right">Műveletek</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-5">
                    <p className="font-bold text-slate-900">{u.name || "Nincs megadva"}</p>
                    <p className="text-sm font-medium text-slate-500">{u.email}</p>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex gap-2 flex-wrap max-w-xs">
                      {u.permissions?.manageNews && <span className="px-2.5 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-lg">Hírek</span>}
                      {u.permissions?.manageTimetable && <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold rounded-lg">Órarend</span>}
                      {u.permissions?.manageSettings && <span className="px-2.5 py-1 bg-orange-100 text-orange-700 text-xs font-bold rounded-lg">Rendszer</span>}
                      {u.permissions?.manageUsers && <span className="px-2.5 py-1 bg-red-100 text-red-700 text-xs font-bold rounded-lg">Adminok</span>}
                      {(!u.permissions || Object.values(u.permissions).every(v => !v)) && <span className="text-slate-400 text-sm italic">Nincs jogosultsága</span>}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-right flex items-center justify-end gap-2">
                    <button onClick={() => handleEdit(u)} className="text-blue-600 hover:bg-blue-50 font-bold px-3 py-2 rounded-xl flex items-center gap-2 transition-colors">
                      <Edit2 className="w-4 h-4" /> Szerkesztés
                    </button>
                    <button onClick={() => handleDeleteUser(u.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-xl transition-colors">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}