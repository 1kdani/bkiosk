"use client";

import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { doc, getDoc, setDoc, updateDoc, arrayUnion, arrayRemove } from "firebase/firestore";
import { Save, Loader2, CalendarDays, Plus, Trash2, Settings2, UploadCloud } from "lucide-react";

const days = ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek"];
const periods = ["1.", "2.", "3.", "4.", "5.", "6.", "7.", "8."];
type ScheduleData = Record<string, Record<string, { subject: string; room: string; teacher: string }>>;
interface MetaData { subjects: string[]; teachers: string[]; rooms: string[]; classes: string[]; }

export default function TimetableAdminPage() {
  const [metaData, setMetaData] = useState<MetaData>({ subjects: [], teachers: [], rooms: [], classes: ["9.A"] });
  const [selectedClass, setSelectedClass] = useState("9.A");
  const [schedule, setSchedule] = useState<ScheduleData>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [showMetaSettings, setShowMetaSettings] = useState(false);
  const [newMetaValue, setNewMetaValue] = useState("");
  const [activeMetaTab, setActiveMetaTab] = useState<keyof MetaData>("classes");

  useEffect(() => {
    const fetchMeta = async () => {
      const metaDoc = await getDoc(doc(db, "settings", "timetable_meta"));
      if (metaDoc.exists()) {
        const data = metaDoc.data() as MetaData;
        setMetaData({ ...data, classes: data.classes || ["9.A"] });
        if (data.classes && data.classes.length > 0) setSelectedClass(data.classes[0]);
      } else {
        await setDoc(doc(db, "settings", "timetable_meta"), { subjects: [], teachers: [], rooms: [], classes: ["9.A"] });
      }
    };
    fetchMeta();
  }, []);

  useEffect(() => {
    const fetchSchedule = async () => {
      if (!selectedClass) return;
      setLoading(true);
      const scheduleDoc = await getDoc(doc(db, "timetables", selectedClass));
      if (scheduleDoc.exists() && scheduleDoc.data().schedule) setSchedule(scheduleDoc.data().schedule);
      else setSchedule({});
      setLoading(false);
    };
    fetchSchedule();
  }, [selectedClass]);

  const handleAddMeta = async () => {
    if (!newMetaValue.trim()) return;
    await updateDoc(doc(db, "settings", "timetable_meta"), { [activeMetaTab]: arrayUnion(newMetaValue.trim()) });
    setMetaData(prev => ({ ...prev, [activeMetaTab]: [...prev[activeMetaTab], newMetaValue.trim()] }));
    if (activeMetaTab === "classes" && metaData.classes.length === 0) setSelectedClass(newMetaValue.trim());
    setNewMetaValue("");
  };

  const handleRemoveMeta = async (value: string) => {
    await updateDoc(doc(db, "settings", "timetable_meta"), { [activeMetaTab]: arrayRemove(value) });
    setMetaData(prev => ({ ...prev, [activeMetaTab]: prev[activeMetaTab].filter(item => item !== value) }));
  };

  const handleChange = (day: string, period: string, field: "subject" | "room" | "teacher", value: string) => {
    setSchedule(prev => ({ ...prev, [day]: { ...prev[day], [period]: { ...prev[day]?.[period], [field]: value } } }));
  };

  const handleSaveSchedule = async () => {
    setSaving(true);
    await setDoc(doc(db, "timetables", selectedClass), { schedule });
    setSaving(false);
    alert(`${selectedClass} órarendje mentve!`);
  };

  // --- EXCEL IMPORTÁLÁS LOGIKÁJA ---
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm("Figyelem! Az importálás felülírja a jelenlegi órarendeket és alapadatokat. Biztosan folytatod?")) {
      e.target.value = "";
      return;
    }

    setIsImporting(true);
    try {
      // Dinamikus import, hogy ne terheljük feleslegesen a memóriát amíg nem kell
      const XLSX = await import("xlsx");
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const sheetName = workbook.SheetNames.find(n => n.includes("Órarend")) || workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json(sheet) as any[];

      const newSubjects = new Set<string>();
      const newTeachers = new Set<string>();
      const newRooms = new Set<string>();
      const classSchedules: Record<string, ScheduleData> = {};

      rows.forEach(row => {
        const day = row['Nap'];
        let periodRaw = row['Óra (adott napon belül)'];
        if (!day || periodRaw === undefined) return;

        const validDays = ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek"];
        if (!validDays.includes(day)) return;

        const period = periodRaw + ".";
        const subject = row['Tantárgy'] ? String(row['Tantárgy']).trim() : "";
        const teacher = row['Tanár'] ? String(row['Tanár']).trim() : "";
        const room = row['Helyiség'] ? String(row['Helyiség']).trim() : "";

        if (subject) newSubjects.add(subject);
        if (teacher) newTeachers.add(teacher);
        if (room) newRooms.add(room);

        // Osztály kinyerése (vagy ha üres, a Csoport első szavából)
        let rawClass = row['Osztály'] ? String(row['Osztály']).trim() : "";
        if (!rawClass && row['Csoport']) {
          rawClass = String(row['Csoport']).trim().split(" ")[0];
        }
        if (!rawClass || rawClass === "nan") return;

        // Intelligens osztály bontás (pl. 10ACDEF -> 10.A, 10.C, 10.D... vagy 9KNY -> 9.KNY)
        let resolvedClasses: string[] = [];
        const match = rawClass.match(/^(\d+)(.*)$/);
        if (match) {
          const grade = match[1];
          const rest = match[2].toUpperCase().trim();
          if (rest === "KNY") {
            resolvedClasses.push(`${grade}.KNY`);
          } else if (/^[A-I]+$/.test(rest)) {
            // Összevont évfolyamszintű csoport
            for (const letter of rest) {
              resolvedClasses.push(`${grade}.${letter}`);
            }
          } else if (rest === "") {
            resolvedClasses.push(`${grade}. évfolyam`);
          } else {
            resolvedClasses.push(`${grade}.${rest}`);
          }
        } else {
          resolvedClasses.push(rawClass);
        }

        // Beszúrás az összes érintett osztály órarendjébe
        resolvedClasses.forEach(cls => {
          if (!classSchedules[cls]) classSchedules[cls] = {};
          if (!classSchedules[cls][day]) classSchedules[cls][day] = {};
          classSchedules[cls][day][period] = { subject, room, teacher };
        });
      });

      const finalSubjects = Array.from(newSubjects).sort();
      const finalTeachers = Array.from(newTeachers).sort();
      const finalRooms = Array.from(newRooms).sort();
      const finalClasses = Object.keys(classSchedules).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

      // Adatok mentése a Firestore-ba
      await setDoc(doc(db, "settings", "timetable_meta"), {
        subjects: finalSubjects, teachers: finalTeachers, rooms: finalRooms, classes: finalClasses
      });

      // Órarendek mentése darabokban (hogy ne terheljük túl az adatbázist)
      const chunkArray = (arr: any[], size: number) => 
        Array.from({ length: Math.ceil(arr.length / size) }, (v, i) => arr.slice(i * size, i * size + size));

      const classChunks = chunkArray(finalClasses, 20);
      for (const chunk of classChunks) {
        await Promise.all(chunk.map(cls => 
          setDoc(doc(db, "timetables", cls), { schedule: classSchedules[cls] })
        ));
      }

      setMetaData({ subjects: finalSubjects, teachers: finalTeachers, rooms: finalRooms, classes: finalClasses });
      
      if (finalClasses.length > 0) {
        setSelectedClass(finalClasses[0]);
        setSchedule(classSchedules[finalClasses[0]]);
      }

      alert("Sikeres importálás!");
    } catch (error) {
      console.error(error);
      alert("Hiba az importálás során!");
    } finally {
      setIsImporting(false);
      if (e.target) e.target.value = "";
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 md:space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Órarendek Szerkesztője</h1>
        </div>
        <div className="flex flex-wrap gap-2 md:gap-4 w-full md:w-auto">
          {/* ÚJ: EXCEL IMPORT GOMB */}
          <label className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 md:px-6 md:py-3 rounded-xl font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md shadow-emerald-200">
            {isImporting ? <Loader2 className="w-5 h-5 animate-spin" /> : <UploadCloud className="w-5 h-5" />}
            {isImporting ? "Importálás..." : "Excel Import"}
            <input type="file" accept=".xlsx, .xls" className="hidden" onChange={handleFileUpload} disabled={isImporting || loading} />
          </label>
          <button onClick={() => setShowMetaSettings(!showMetaSettings)} className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 md:px-6 md:py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-sm">
            <Settings2 className="w-5 h-5" /> {showMetaSettings ? "Rejtés" : "Alapadatok"}
          </button>
          <button onClick={handleSaveSchedule} disabled={saving || loading || isImporting} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 md:px-6 md:py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-md shadow-blue-200 disabled:opacity-50">
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />} Mentés
          </button>
        </div>
      </div>

      {showMetaSettings && (
        <div className="bg-white p-4 md:p-8 rounded-3xl shadow-lg border border-slate-200 animate-in fade-in">
          <div className="flex flex-wrap gap-2 mb-6">
            {[ {id: "classes", name: "Osztályok"}, {id: "subjects", name: "Tantárgyak"}, {id: "teachers", name: "Tanárok"}, {id: "rooms", name: "Termek"} ].map(tab => (
              <button key={tab.id} onClick={() => setActiveMetaTab(tab.id as keyof MetaData)} className={`px-4 py-2 rounded-lg font-bold ${activeMetaTab === tab.id ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}>
                {tab.name}
              </button>
            ))}
          </div>
          <div className="flex gap-2 mb-4">
            <input type="text" value={newMetaValue} onChange={(e) => setNewMetaValue(e.target.value)} placeholder={`Új ${activeMetaTab} hozzáadása...`} className="flex-1 px-4 py-2 rounded-lg border border-slate-300 outline-none font-bold text-slate-900" />
            <button onClick={handleAddMeta} className="bg-blue-600 text-white p-2 px-6 font-bold rounded-lg"><Plus className="w-5 h-5"/></button>
          </div>
          <div className="max-h-60 overflow-y-auto grid grid-cols-2 md:grid-cols-4 gap-2">
            {metaData[activeMetaTab].map(item => (
              <div key={item} className="flex justify-between items-center bg-slate-50 px-3 py-2 rounded-lg border border-slate-200 text-sm font-bold text-slate-900">
                {item} <button onClick={() => handleRemoveMeta(item)} className="text-red-500"><Trash2 className="w-4 h-4"/></button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row items-start md:items-center gap-4">
        <CalendarDays className="w-6 h-6 text-blue-600 hidden md:block" />
        <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} className="w-full md:w-auto px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-black text-slate-900 bg-slate-50 text-lg">
          {metaData.classes.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr>
                <th className="p-4 bg-slate-50 border-b border-r border-slate-200 font-bold text-center w-20 text-slate-500">Óra</th>
                {days.map(day => <th key={day} className="p-4 bg-slate-50 border-b border-slate-200 font-black text-center text-slate-800 uppercase">{day}</th>)}
              </tr>
            </thead>
            <tbody>
              {periods.map((period) => (
                <tr key={period} className="hover:bg-slate-50/50">
                  <td className="p-4 border-b border-r border-slate-200 text-center font-black text-slate-900 bg-slate-50/50">{period}</td>
                  {days.map((day) => {
                    const lesson = schedule[day]?.[period] || { subject: "", room: "", teacher: "" };
                    return (
                      <td key={`${day}-${period}`} className="p-3 border-b border-slate-200 border-dashed align-top">
                        <div className="flex flex-col gap-2 bg-white p-2 rounded-xl border border-slate-100 focus-within:border-blue-400 transition-all">
                          <select value={lesson.subject} onChange={(e) => handleChange(day, period, "subject", e.target.value)} className="w-full px-2 py-1.5 text-sm font-black border border-slate-200 rounded-lg outline-none bg-slate-50 text-slate-900">
                            <option value="">- Tantárgy -</option>{metaData.subjects.map(s => <option key={s} value={s}>{s}</option>)}
                          </select>
                          <div className="flex gap-2">
                            <select value={lesson.room} onChange={(e) => handleChange(day, period, "room", e.target.value)} className="w-1/2 px-2 py-1 text-xs font-bold border border-slate-200 rounded-lg outline-none bg-slate-50 text-slate-900">
                              <option value="">- Terem -</option>{metaData.rooms.map(r => <option key={r} value={r}>{r}</option>)}
                            </select>
                            <select value={lesson.teacher} onChange={(e) => handleChange(day, period, "teacher", e.target.value)} className="w-1/2 px-2 py-1 text-xs font-bold border border-slate-200 rounded-lg outline-none bg-slate-50 text-slate-900">
                              <option value="">- Tanár -</option>{metaData.teachers.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                          </div>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}