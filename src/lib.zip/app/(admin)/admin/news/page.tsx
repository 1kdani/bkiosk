"use client";

import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, addDoc, getDocs, deleteDoc, updateDoc, doc, serverTimestamp, query, orderBy } from "firebase/firestore";
import { Plus, Trash2, Edit2, Loader2, X, Palette, LayoutTemplate, Image as ImageIcon, UploadCloud } from "lucide-react";
import dynamic from 'next/dynamic';
// Itt már az ÚJ, React 19 kompatibilis csomagot importáljuk!
import 'react-quill-new/dist/quill.snow.css';

const ReactQuill = dynamic(() => import('react-quill-new'), { 
  ssr: false,
  loading: () => <div className="p-4 text-slate-400 font-medium">Szerkesztő betöltése...</div>
}) as any;

interface NewsItem {
  id: string;
  title: string;
  content: string;
  tag: string;
  color: string;
  template: "default" | "image-left" | "image-top";
  imageUrl?: string;
}

interface NewsFormData {
  title: string;
  content: string;
  tag: string;
  color: string;
  template: "default" | "image-left" | "image-top";
  imageUrl: string;
}

const modules = {
  toolbar: [
    [{ 'header': [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
    [{ 'color': [] }, { 'background': [] }],
    ['clean']
  ],
};

export default function NewsAdminPage() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const defaultForm: NewsFormData = { 
    title: "", content: "", tag: "Információ", color: "#3b82f6", template: "default", imageUrl: "" 
  };
  
  const [formData, setFormData] = useState<NewsFormData>(defaultForm);

  const fetchNews = async () => {
    try {
      const q = query(collection(db, "news"), orderBy("createdAt", "desc"));
      const querySnapshot = await getDocs(q);
      const newsData: NewsItem[] = querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          title: data.title || "",
          content: data.content || "",
          tag: data.tag || "",
          color: data.color || "#3b82f6",
          template: (data.template as "default" | "image-left" | "image-top") || "default",
          imageUrl: data.imageUrl || "",
        };
      });
      setNews(newsData);
    } catch (error) { console.error(error); } 
    finally { setLoading(false); }
  };

  useEffect(() => { fetchNews(); }, []);

  // --- KÉPFELTÖLTÉS (Cloudinary) ---
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    try {
      const data = new FormData();
      data.append("file", file);
      // FONTOS: Cseréld ki a bathory_preset és a te_cloud_neved részeket a sajátodra!
      data.append("upload_preset", "bathory_preset"); 
      const res = await fetch("https://api.cloudinary.com/v1_1/te_cloud_neved/image/upload", {
        method: "POST",
        body: data,
      });
      const fileData = await res.json();
      setFormData(prev => ({ ...prev, imageUrl: fileData.secure_url }));
    } catch (error) {
      alert("Hiba a kép feltöltésekor!");
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleEdit = (item: NewsItem) => {
    setFormData({ 
      title: item.title, content: item.content, tag: item.tag, 
      color: item.color, template: item.template, imageUrl: item.imageUrl || "" 
    });
    setEditingId(item.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancel = () => {
    setFormData(defaultForm);
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      if (editingId) {
        await updateDoc(doc(db, "news", editingId), { ...formData });
      } else {
        await addDoc(collection(db, "news"), { ...formData, createdAt: serverTimestamp() });
      }
      handleCancel();
      fetchNews();
    } catch (error) { console.error(error); } 
    finally { setIsSubmitting(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Biztosan törölni szeretnéd ezt a hírt?")) {
      await deleteDoc(doc(db, "news", id));
      fetchNews();
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Hírek kezelése</h1>
          <p className="text-slate-500 mt-1 font-medium">Szerkeszd a TV-n futó híreket Word-szerű formázással.</p>
        </div>
        {!showForm && (
          <button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-md shadow-blue-200">
            <Plus className="w-5 h-5" /> Új hír hozzáadása
          </button>
        )}
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-lg border border-slate-200 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-4">
            <h2 className="text-2xl font-bold text-slate-800">{editingId ? "Hír módosítása" : "Új hír létrehozása"}</h2>
            <div className="flex gap-4 items-center">
              <div className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-xl border border-slate-200">
                <Palette className="w-5 h-5 text-slate-400" />
                <span className="text-sm font-bold text-slate-600">TV Háttérszín:</span>
                <input type="color" value={formData.color} onChange={(e) => setFormData({...formData, color: e.target.value})} className="w-8 h-8 rounded cursor-pointer border-0" />
              </div>
              <div className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-xl border border-slate-200">
                <LayoutTemplate className="w-5 h-5 text-slate-400" />
                <span className="text-sm font-bold text-slate-600">Sablon:</span>
                <select value={formData.template} onChange={(e) => setFormData({...formData, template: e.target.value as any})} className="bg-transparent font-bold text-slate-800 outline-none">
                  <option value="default">Szöveg középen (Nincs kép)</option>
                  <option value="image-left">Kép bal oldalon</option>
                  <option value="image-top">Kép felül</option>
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Hír címe (Nagy betűs)</label>
                <input required type="text" value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} className="w-full px-5 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 font-bold text-lg" placeholder="pl. Gólyabál 2026" />
                
                <label className="block text-sm font-bold text-slate-700 mb-2 mt-6">Címke (Tag)</label>
                <input required type="text" value={formData.tag} onChange={(e) => setFormData({...formData, tag: e.target.value})} className="w-full px-5 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 font-bold text-lg" placeholder="pl. Fontos, Kiemelt" />
              </div>
              
              {/* Képfeltöltő Szekció */}
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Borítókép (Opcionális de ajánlott)</label>
                {formData.imageUrl ? (
                  <div className="relative w-full h-[142px] rounded-xl overflow-hidden border border-slate-300 group">
                    <img src={formData.imageUrl} alt="Előnézet" className="w-full h-full object-cover" />
                    <button type="button" onClick={() => setFormData({...formData, imageUrl: ""})} className="absolute top-2 right-2 bg-red-500/90 hover:bg-red-600 text-white p-2 rounded-lg backdrop-blur-sm transition-all shadow-lg opacity-0 group-hover:opacity-100">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <label className="w-full h-[142px] border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl flex flex-col items-center justify-center cursor-pointer transition-colors bg-slate-50 group">
                    {isUploadingImage ? (
                      <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
                    ) : (
                      <>
                        <UploadCloud className="w-8 h-8 text-slate-400 mb-2 group-hover:text-blue-500 transition-colors" />
                        <span className="text-sm font-bold text-slate-500 group-hover:text-blue-600">Kattints a kép feltöltéséhez</span>
                      </>
                    )}
                    <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} disabled={isUploadingImage} />
                  </label>
                )}
              </div>
            </div>

            <div className="pb-12">
              <label className="block text-sm font-bold text-slate-700 mb-2">Hír szövege (Word formázás)</label>
              <div className="bg-white rounded-xl overflow-hidden border border-slate-300 text-slate-900 h-64">
                <ReactQuill value={formData.content} onChange={(content: string) => setFormData({...formData, content})} modules={modules} className="h-52" />
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-4">
            <button type="button" onClick={handleCancel} className="bg-red-50 hover:bg-red-100 text-red-600 px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all">
              <X className="w-5 h-5" /> Mégse
            </button>
            <button type="submit" disabled={isSubmitting} className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-md shadow-green-200 disabled:opacity-50">
              {isSubmitting && <Loader2 className="w-5 h-5 animate-spin" />} {editingId ? "Módosítások mentése" : "Közzététel a TV-n"}
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {news.map((item) => (
            <div key={item.id} className="bg-white rounded-3xl shadow-sm border border-slate-200 flex flex-col overflow-hidden group">
              {item.imageUrl && (
                <div className="w-full h-40 relative">
                  <img src={item.imageUrl} className="w-full h-full object-cover" alt="" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-3 left-4 flex gap-2">
                    <span className="bg-white/20 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full">{item.tag}</span>
                  </div>
                </div>
              )}
              {!item.imageUrl && (
                <div className="h-3 w-full" style={{ backgroundColor: item.color }} />
              )}
              <div className="p-6 flex-1 flex flex-col">
                {!item.imageUrl && (
                  <span className="bg-slate-100 text-slate-600 text-xs font-bold px-3 py-1.5 rounded-full uppercase w-max mb-4">
                    {item.tag} • Sablon: {item.template}
                  </span>
                )}
                <h3 className="text-xl font-black text-slate-900 mb-3 leading-tight">{item.title}</h3>
                <div className="text-slate-500 text-sm mb-6 line-clamp-3 prose prose-sm" dangerouslySetInnerHTML={{ __html: item.content }} />
                <div className="pt-4 border-t border-slate-100 flex justify-between items-center mt-auto">
                  <button onClick={() => handleEdit(item)} className="text-blue-600 hover:bg-blue-50 font-bold px-4 py-2 rounded-xl flex items-center gap-2 transition-colors">
                    <Edit2 className="w-4 h-4" /> Szerkesztés
                  </button>
                  <button onClick={() => handleDelete(item.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-xl transition-colors">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}