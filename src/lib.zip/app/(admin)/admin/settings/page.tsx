"use client";

import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { Save, Plus, Trash2, Loader2, BellRing, Map as MapIcon, Image as ImageIcon, Upload } from "lucide-react";

interface BellClass { id: string; period: string; time: string; breakText: string; }
interface FloorMap { id: string; name: string; imageUrl: string; }

export default function SettingsPage() {
  const [loading, setLoading] = useState(true);
  
  // Csengetési rend state
  const [bells, setBells] = useState<BellClass[]>([]);
  const [savingBells, setSavingBells] = useState(false);

  // Térkép state
  const [floors, setFloors] = useState<FloorMap[]>([]);
  const [savingMaps, setSavingMaps] = useState(false);
  const [uploadingId, setUploadingId] = useState<string | null>(null);

  // Adatok betöltése
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        // Csengetés
        const bellSnap = await getDoc(doc(db, "settings", "bells"));
        if (bellSnap.exists() && bellSnap.data().schedule) setBells(bellSnap.data().schedule);
        else setBells([{ id: "1", period: "1. óra", time: "08:00 - 08:45", breakText: "10 perc" }]);

        // Térkép
        const mapSnap = await getDoc(doc(db, "settings", "maps"));
        if (mapSnap.exists() && mapSnap.data().floors) setFloors(mapSnap.data().floors);
      } catch (error) {
        console.error("Hiba a betöltéskor:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  // --- CSENGETÉSI REND LOGIKA ---
  const handleSaveBells = async () => {
    setSavingBells(true);
    try {
      await setDoc(doc(db, "settings", "bells"), { schedule: bells });
      alert("Csengetési rend mentve!");
    } catch (e) { alert("Hiba mentéskor!"); }
    setSavingBells(false);
  };

  // --- TÉRKÉP LOGIKA ÉS KÉPFELTÖLTÉS (Cloudinary) ---
  const uploadImageToCloudinary = async (file: File) => {
    const data = new FormData();
    data.append("file", file);
    data.append("upload_preset", "bathory_preset"); // <-- Cseréld a Cloudinary preset-re!
    const res = await fetch("https://api.cloudinary.com/v1_1/rfcmhupl/image/upload", { // <-- Cseréld a Cloud Névre!
      method: "POST",
      body: data,
    });
    const fileData = await res.json();
    return fileData.secure_url;
  };

  const handleImageUpload = async (floorId: string, file: File) => {
    setUploadingId(floorId);
    try {
      const url = await uploadImageToCloudinary(file);
      setFloors(floors.map(f => f.id === floorId ? { ...f, imageUrl: url } : f));
    } catch (error) {
      alert("Hiba a kép feltöltésekor!");
    } finally {
      setUploadingId(null);
    }
  };

  const handleSaveMaps = async () => {
    setSavingMaps(true);
    try {
      await setDoc(doc(db, "settings", "maps"), { floors });
      alert("Térképek mentve!");
    } catch (e) { alert("Hiba mentéskor!"); }
    setSavingMaps(false);
  };

  if (loading) return <div className="p-12 flex justify-center"><Loader2 className="w-12 h-12 animate-spin text-blue-500" /></div>;

  return (
    <div className="max-w-4xl mx-auto pb-12 space-y-12">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Rendszer Beállítások</h1>
        <p className="text-gray-500 mt-1">Kezeld a statikus tartalmakat a TV panelekhez.</p>
      </div>

      {/* 1. CSENGETÉSI REND SZEKCIÓ */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-200">
        <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-50 rounded-xl"><BellRing className="w-6 h-6 text-purple-600" /></div>
            <h2 className="text-xl font-bold text-gray-800">Csengetési Rend</h2>
          </div>
          <button onClick={handleSaveBells} disabled={savingBells} className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-lg font-medium flex items-center gap-2">
            {savingBells ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Mentés
          </button>
        </div>

        <div className="space-y-4">
          {bells.map((bell, index) => (
            <div key={bell.id} className="flex gap-4 items-center bg-gray-50 p-4 rounded-xl border border-gray-100">
              <div className="font-bold text-slate-800 w-6">{index + 1}.</div>
              <input 
                type="text" 
                placeholder="1. óra" 
                value={bell.period} 
                onChange={(e) => setBells(bells.map(b => b.id === bell.id ? { ...b, period: e.target.value } : b))} 
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg outline-none focus:border-purple-500 text-slate-900 font-bold" 
              />
              <input 
                type="text" 
                placeholder="08:00 - 08:45" 
                value={bell.time} 
                onChange={(e) => setBells(bells.map(b => b.id === bell.id ? { ...b, time: e.target.value } : b))} 
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg outline-none focus:border-purple-500 font-mono text-slate-900 font-bold" 
              />
              <input 
                type="text" 
                placeholder="10 perc" 
                value={bell.breakText} 
                onChange={(e) => setBells(bells.map(b => b.id === bell.id ? { ...b, breakText: e.target.value } : b))} 
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg outline-none focus:border-purple-500 text-slate-900 font-bold" 
              />
              <button onClick={() => setBells(bells.filter(b => b.id !== bell.id))} className="text-red-500 hover:bg-red-50 p-2 rounded-lg">
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}
          <button onClick={() => setBells([...bells, { id: Date.now().toString(), period: "", time: "", breakText: "" }])} className="text-purple-600 font-bold hover:bg-purple-50 px-4 py-2 rounded-lg flex items-center gap-2">
            <Plus className="w-5 h-5" /> Új tanóra
          </button>
          </div>
        </div>

      {/* 2. ISKOLA TÉRKÉP SZEKCIÓ */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-200">
        <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-50 rounded-xl"><MapIcon className="w-6 h-6 text-orange-600" /></div>
            <h2 className="text-xl font-bold text-gray-800">Iskola Térkép Alaprajzok</h2>
          </div>
          <button onClick={handleSaveMaps} disabled={savingMaps} className="bg-orange-600 hover:bg-orange-700 text-white px-5 py-2 rounded-lg font-medium flex items-center gap-2">
            {savingMaps ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Mentés
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {floors.map((floor) => (
            <div key={floor.id} className="bg-gray-50 border border-gray-200 rounded-2xl overflow-hidden flex flex-col">
              <div className="p-4 bg-white border-b border-gray-200 flex items-center gap-2">
                <input type="text" placeholder="Szint neve (pl. 1. emelet)" value={floor.name} onChange={(e) => setFloors(floors.map(f => f.id === floor.id ? { ...f, name: e.target.value } : f))} className="flex-1 px-3 py-1.5 border border-gray-300 rounded-lg outline-none focus:border-orange-500 font-bold" />
                <button onClick={() => setFloors(floors.filter(f => f.id !== floor.id))} className="text-red-500 hover:bg-red-50 p-2 rounded-lg"><Trash2 className="w-5 h-5" /></button>
              </div>
              
              <div className="p-6 flex-1 flex flex-col items-center justify-center relative">
                {floor.imageUrl ? (
                  <div className="relative w-full h-48 bg-white border border-gray-200 rounded-xl overflow-hidden group">
                    <img src={floor.imageUrl} alt="Alaprajz" className="w-full h-full object-contain p-2" />
                    <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                      <span className="text-white font-bold flex items-center gap-2"><Upload className="w-5 h-5"/> Kép cseréje</span>
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => e.target.files && handleImageUpload(floor.id, e.target.files[0])} />
                    </label>
                  </div>
                ) : (
                  <label className="w-full h-48 border-2 border-dashed border-gray-300 hover:border-orange-500 rounded-xl flex flex-col items-center justify-center cursor-pointer transition-colors bg-white">
                    {uploadingId === floor.id ? (
                      <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
                    ) : (
                      <>
                        <ImageIcon className="w-8 h-8 text-gray-400 mb-2" />
                        <span className="text-sm font-medium text-gray-500">Alaprajz feltöltése</span>
                      </>
                    )}
                    <input type="file" className="hidden" accept="image/*" onChange={(e) => e.target.files && handleImageUpload(floor.id, e.target.files[0])} disabled={uploadingId === floor.id} />
                  </label>
                )}
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => setFloors([...floors, { id: Date.now().toString(), name: "Új emelet", imageUrl: "" }])} className="mt-6 text-orange-600 font-medium hover:bg-orange-50 px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus className="w-5 h-5" /> Új emelet / térkép hozzáadása
        </button>
      </div>

    </div>
  );
}