"use client";

import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { useStore } from "@/store/useStore";
import { useRouter, usePathname } from "next/navigation";
import Sidebar from "@/components/admin/Sidebar";
import { Loader2 } from "lucide-react";


export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, setUser, setUserData } = useStore(); 
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const userDoc = await getDoc(doc(db, "users", currentUser.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            // Csak az új, részletes adatokat olvassuk be:
            setUserData(data.name || "Felhasználó", data.permissions || {
              manageNews: false, manageTimetable: false, manageSettings: false, manageUsers: false
            });
          } else {
            setUserData(null, null);
          }
        } catch (error) {
          console.error("Hiba a jogosultság lekérésekor:", error);
        }
      } else {
        setUser(null);
        setUserData(null, null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [setUser, setUserData]);

  // 2. Kliens oldali routing védelem
  useEffect(() => {
    if (loading) return; // Várjuk meg, amíg kiderül, belépett-e

    // Ha nincs belépve, és nem a login oldalon van -> irány a login
    if (!user && pathname !== "/admin/login") {
      router.replace("/admin/login");
    } 
    // Ha be van lépve, és a login oldalon van -> irány az admin főoldal
    else if (user && pathname === "/admin/login") {
      router.replace("/admin");
    }
  }, [user, loading, pathname, router]);

  // Töltőképernyő amíg a Firebase válaszol
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
        {/* Ezt a rejtett div-et hozzáadva a Next.js 15 statikus elemzője megnyugszik */}
        <div className="hidden">{children}</div>
      </div>
    );
  }

  // Ha a login oldalon vagyunk, nem mutatjuk a sidebart (csak a children-t)
  if (pathname === "/admin/login") {
    return <div className="min-h-screen bg-gray-50">{children}</div>;
  }

  // Ha be vagyunk lépve és nem a loginon vagyunk, mutatjuk a teljes Admin felületet
  return (
    <div className="min-h-screen bg-gray-100 flex font-sans">
      <Sidebar />
      <main className="flex-1 p-10 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}